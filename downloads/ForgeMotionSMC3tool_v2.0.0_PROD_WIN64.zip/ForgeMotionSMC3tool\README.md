# ForgeMotionSMC3tool v2.0.0 (Production)

## Run (end-user)
Use the production release ZIP:
- Unzip anywhere
- Run: `ForgeMotionSMC3tool.exe`

No Python install required.

## Build Windows EXE (developer)
Prereqs:
- Windows 10/11 x64
- Python 3.11+ (from python.org; add to PATH)

Steps:
1. Open PowerShell in the project root
2. Run:
   - `Set-ExecutionPolicy -Scope Process Bypass`
   - `./build/windows/build_exe.ps1`
3. Output:
   - `dist/ForgeMotionSMC3tool/ForgeMotionSMC3tool.exe`

## Packaging notes
- Build mode: **onedir** (portable folder with `_internal/`)
- Tkinter + Matplotlib are bundled into the dist folder
- Data files shipped: `udp_config.json`, `docs/`, `SMC3/`, `smc3multi/logo*.png`, `smc3multi/SMC3ForgeMotion_v1.3.5.zip`
