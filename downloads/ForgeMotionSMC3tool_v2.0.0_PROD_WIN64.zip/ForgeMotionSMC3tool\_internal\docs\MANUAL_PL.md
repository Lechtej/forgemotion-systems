# ForgeMotionSMC3tool — Instrukcja (PL)

## 1. Cel aplikacji
ForgeMotionSMC3tool to aplikacja do strojenia i testów **wielu** kontrolerów Arduino zgodnych z SMC3 (multi-board / 2 silniki na płytkę).

## 2. Bezpieczeństwo (najpierw przeczytaj)
- Pierwsze testy wykonuj na podniesionej / odciążonej ramie.
- **ENA (Enable)** włączaj dopiero, gdy jesteś gotowy na ruch.
- Preferuj tryb **Zastosuj-Safe** (domyślny). Pełne Zastosuj jest dostępne tylko po świadomym potwierdzeniu zmian ryzykownych.
- Gdy coś jest nie tak: **wyłącz ENA**, zatrzymaj tryb ruchu, rozłącz.

## 3. Połączenie
1. Wybierz numer portu COM (np. `7` → `COM7`).
2. Kliknij **Połącz**.
3. Potwierdź telemetrię na wykresach (seria Feedback).

## 4. Baseline (Read-back)
Użyj **Przywróć z Arduino** (osobno dla silnika), aby wczytać wartości z Arduino do UI i ustawić baseline dla bezpiecznego gatingu.

## 5. Strojenie (zalecany przebieg)
1. Zacznij w **Monitor**.
2. Zmień PID / PWM / limity w UI.
3. Kliknij **Wyślij do Arduino** (tylko zmiany SAFE).
4. Zweryfikuj na wykresach (Target vs Feedback) i na zachowaniu mechaniki.
5. Zapis:
   - **Zapisz EEPROM (sav)** aby utrwalić w Arduino, lub
   - **Zapisz INI** aby zachować profile na PC (multi-board).

## 6. Tryby (przegląd)
- **Monitor**: tylko telemetria (aplikacja nie wysyła targetu).
- **Ręczny**: wysyła target A/B z suwaków.
- **Sinus / Trójkąt / Prostokąt / Ruch**: generatory targetów do testów (ostrożnie).
- **UDP pass-through**: targety przez UDP (patrz `udp_config.json`).

## 7. Wykresy
- **Target**: pozycja zadana
- **Feedback**: pozycja zmierzona
- **PWM (skalowane)**: wysterowanie (skalowane do wykresu)

Linie limitów (Clip / Cutoff) pokazują skonfigurowane ograniczenia.

## 8. Ograniczenia
- Aplikacja nie zastępuje zabezpieczeń sprzętowych (bezpieczniki, E-stop, ograniczniki).
- Generatory mogą wywołać agresywny ruch przy złej konfiguracji.

