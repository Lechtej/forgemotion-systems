# Disclaimer (EN)

This application’s **testing workflow** and **plot concepts** are based on the SMC3 ecosystem and the SMC3Utils tooling approach.

**ForgeMotionSMC3tool** is a separate, fully new implementation written from scratch, created to support and simplify work with **multi-board / multi-motor** simulator setups (more than one Arduino controller board).

- SMC3 / SMC3Utils are referenced for conceptual compatibility.
- ForgeMotionSMC3tool is not an official SMC3 project and is not affiliated with the original authors.
- Use at your own risk. Always validate safety on your hardware (E-stop, fuses, mechanical limits).

