# Apply Safe — Checklist testów (Freeze)

## 1) Baseline / Read-back
- Start → BL:no
- Connect → Read-back OK (16/16) → BL:yes INI:no NO_CHANGES

## 2) SAFE
- Zmień Kp / PWM / lim / clip / dead → READY_SAFE
- Klik Apply → SAFE_APPLY → NO_CHANGES

## 3) RISKY
- Zmień fpwm / divider / pwmrev / ks → READY_RISKY
- Klik Apply bez SHIFT → blok + warning
- SHIFT+Apply + confirm → pełny Apply

## 4) Zależności (INVALID)
- Ustaw clip > lim (lub dead > clip, itp.) → INVALID i Apply zablokowane

## 5) INI
- Load INI bez baseline → RB_REQUIRED i Apply zablokowane
- Save INI bez baseline → blok
- Load INI z baseline → INI:yes READY_*
- Apply → INI pending cleared → INI:no
