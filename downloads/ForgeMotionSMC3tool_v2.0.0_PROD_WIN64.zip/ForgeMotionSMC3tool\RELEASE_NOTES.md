## v2.0.0 — Production build: Windows EXE (PyInstaller)

Date: 2026-02-03

### Packaging
- Added Windows build pipeline (PyInstaller spec + PowerShell scripts) to produce a portable EXE distribution (no Python required on target machine).
- Added app icon for EXE.
- Release artifact: `ForgeMotionSMC3tool_v2.0.0_PROD_WIN64.zip` (portable folder: `ForgeMotionSMC3tool.exe` + `_internal/`).

### Notes
- Runtime logic, protocol, and safety behavior unchanged vs v1.5.4 (packaging-only release).

---

## v1.5.4 — UX: authorization popup polish
- UX: improved soft-authorization popup layout:
  - better padding and typography
  - added subtle website link cue (clickable)
  - added keyboard support (Enter = authorize, Esc = exit)
- No changes to motion control logic, runtime validation behavior, firmware/protocol, or Apply/Save/Restore.

## v1.5.3 — i18n: refresh Profiles board selector values on language switch

Date: 2026-01-19

### UI / i18n (no control/protocol changes)
- i18n: Profiles → "Copy this board to…" combobox now refreshes its option labels when switching PL/EN.
  - Fixes: EN view showing Polish options (e.g., "Wszystkie płytki", "Płytka 2") after language toggle.

---

## v1.4.47 — i18n: missing keys + UI: wrapped mode hint (no control/protocol changes)

Date: 2026-01-13

### UI / i18n (no control/protocol changes)
- i18n: added missing keys (EN+PL) to prevent raw key names showing in UI:
  - close_anyway_title / close_anyway_msg
  - mode_motion_desc / mode_udp_desc
  - status_not_connected
- i18n: added missing PL labels for plot series:
  - series_target / series_feedback / series_pwm
- UI: Mode description (hint) now wraps to panel width for readability.
- UI: window title version updated to v1.4.47.

---

## v1.4.44 — HELP: Manual v1.1 + Quick Start + Tuning Checklist + i18n fixes

Date: 2026-01-12

### UI / Docs (no control/protocol changes)
- Help menu (header, right) extended with:
  - Manual / Instrukcja **v1.1** (embedded text, PL/EN; expanded Tuning explanations + startup procedure after flashing firmware)
  - Quick Start (embedded text, PL/EN; single-screen)
  - Tuning Checklist (embedded text, PL/EN)
  - Disclaimer (embedded text, PL/EN)
  - SMC3 Firmware (INO): bundled ZIP + override folder `./SMC3/`
- i18n fixes:
  - EN labels for Help/Manual/Quick Start/Checklist/Disclaimer/Firmware are English
  - PL: “All boards” translated to “Wszystkie płytki” in Profiles dropdown
  - PL/EN: COM/EEPROM blocking messages translated consistently

---

## v1.4.43 — HELP: Manual + Disclaimer + SMC3 Firmware (bundled + override)

Date: 2026-01-11

### UI / Docs (no control/protocol changes)
- Help menu (header, right) extended with:
  - Manual / Instrukcja (embedded text, PL/EN)
  - Disclaimer (embedded text, PL/EN)
  - SMC3 Firmware (INO):
    - **Bundled ZIP**: `smc3multi/SMC3ForgeMotion_v1.3.5.zip`
    - **Override folder**: `./SMC3/` (next to app)
    - Buttons: Open folder, Export bundled to `./SMC3/`, Download bundled ZIP
    - Source/status shown (Override vs Bundled)
- i18n/UI fixes:
  - Copy destination label uses i18n (`All boards` → `Wszystkie płytki` in PL).
  - "Connect to COM first" warnings are PL/EN via i18n.

### Safety / Logic
- No changes in: control logic, Apply gating, validation rules, firmware/protocol, UDP.

---

## v1.4.39 — UI0: i18n cleanup + Manual/Disclaimer popups

Date: 2026-01-11

### UI (no control/protocol changes)
- Removed leftover “(soon)” suffixes from mode names (UI labels only).
- i18n audit fixes:
  - Eliminated PL/EN mixed strings in dialogs/tooltips.
  - Moved remaining hard-coded Polish dialog texts into i18n (EN/PL).
  - Kept series names **Target / Feedback / PWM** as English in both languages (by design).
- Added **Help** menu in the header (right side) with:
  - **Manual / Instrukcja** popup (language-dependent)
  - **Disclaimer** popup (language-dependent)

### Safety / Logic
- No changes in: control logic, Apply gating, validation rules, firmware/protocol, UDP.

---

# ForgeMotionSMC3tool — Release Notes



## v1.4.38 — APPLY validation fix: remove false dependency Max Limits vs PWM max

- Removed incorrect dependency validation that blocked Apply when **Max Limits (Cutoff)** was greater than **PWM max** (`lim > pwmmax`).
  - These parameters are **independent** in firmware; higher Cutoff/Clip values can increase safety and must remain adjustable across full 0–255.
- Kept existing dependency rules:
  - `PWMmin <= PWMmax`
  - `PWMrev <= PWMmax`
  - `Clip >= MaxLim`
  - `Deadzone <= Clip`
- No changes to control logic, protocol, firmware behavior, layout, or UX baseline (9E.B3e).

## v1.4.36 — UI validation: Clip vs Max Limits (field-level)

- Added **field-level** (live) dependency validation between **Max Limits (Cutoff)** and **Clip Input** to match SMC3/SMC3Utils semantics:
  - **Rule:** `Clip >= MaxLim` (per motor).
  - When **MaxLim** is increased above **Clip**, the UI **auto-raises Clip** to the same value (does not block the safety boundary).
  - When **Clip** is decreased below **MaxLim**, the UI **prevents it** (Clip snaps back to MaxLim; does not silently reduce the Cutoff safety boundary).
- No changes to control logic, protocol, firmware behavior, layout, or UX baseline (9E.B3e).

## v1.4.35 — HOTFIX — APPLY validation (Clip vs Max Limits)

- Fixed dependency validation for **Clip Input** vs **Max Limits (Cutoff)** to match SMC3/SMC3Utils semantics:
  - **Requirement:** `Clip >= MaxLim` (so Target clamp stays *inside* the Cutoff-safe region).
  - Previously (incorrect): `Clip <= MaxLim`, which could block applying higher Clip values (e.g., >85).
- No changes to control logic, protocol, firmware behavior, layout, or UX — **visualization-only thread remains intact**.


## v1.4.34 — HOTFIX: startup crash (IndentationError)

- Fix: `smc3multi/app.py` syntax error (`IndentationError` after duplicated `try:`) that prevented the app from starting.
- **Visual-only patch** — no changes to control logic, protocol, firmware, motion safety, or UI layout (9E.B3e baseline preserved).
- Limit lines remain: **2× Clip (min/max) + 2× MaxLim (min/max)** on Target/Feedback plots (embedded + popup).

## v1.4.33 — UI: SMC3Utils-style limit window (2×Clip + 2×MaxLim) + correct scaling

### Changed
- **Plots (embedded + popup):**
  - Clip Input now drawn as **two lines**: `min = Clip` and `max = 1023 - Clip`.
  - Max Limits (Cutoff) now drawn as **two lines**: `min = Lim` and `max = 1023 - Lim`.
  - **Scaling corrected** to match SMC3ForgeMotion firmware (byte values used directly on 0..1023 axis; no ×4).

### Notes
- **Visualization only** — no changes to control logic, protocol, firmware, motion modes, or layout/UX (baseline 9E.B3e).

## v1.4.32 — UI: limit visualization on plots (Clip Input + Max Limits)

### Added
- **Plots (embedded + popup):**
  - Horizontal line for **Clip Input** (scaled to 10-bit plot range).
  - Horizontal line for **Max Limits** (scaled to 10-bit plot range).

### Notes
- **Visualization only** — no changes to control logic, protocol, firmware, motion modes, or layout/UX (baseline 9E.B3e).

## v1.4.31 — SAFETY FIX: slider value 0 no longer maps to 100%

### Fixed
- **Critical safety issue**: when certain UI sliders were set to **0**, internal code used Python's falsy fallback (`value or default`), which incorrectly treated `0` as "missing" and replaced it with the default (effectively **100%**). This could cause **maximum movement/speed when the slider was at minimum**.
- Range sliders now correctly support **0% = no movement** across **Sine / Triangle / Square / Motion**.

### Safety impact
- Eliminates an unexpected "0% -> 100%" inversion that could drive the rig aggressively.

### Safety
- No behaviour changes vs v1.4.28/v1.4.29: PC-side **A1 clamp** + **A2 slew-rate** still apply to auto modes (Test + Motion). Manual/UDP unchanged.


## v1.4.30 — FIX: Range sliders now affect Sine/Triangle/Square + version label corrected

### Fixed
- **Range M1/M2 sliders** now properly scale the effective amplitude in **Sine / Triangle / Square** (previously they were only applied in Motion).
- App header/version label updated to **v1.4.30** (was still showing an older version string).


## v1.4.29 — HOTFIX: startup crash fix (BoardPanel _mode_display_list) + keep safety changes

### Fixed
- Fixed an indentation/regression that caused app startup to crash with: `AttributeError: 'BoardPanel' object has no attribute '_mode_display_list'`.

### Safety
- No changes to safety behaviour introduced in v1.4.28 (PC-side clamp + slew-rate for Test+Motion, safe defaults). Manual/UDP unchanged.

## v1.4.28 — SAFETY: PC-side Clamp+Slew for auto modes + safe test defaults (NO firmware/protocol/UI changes)

Safety (auto target generators only: Sine / Triangle / Square / Motion):
- **A1 Clamp (PC-side):** target is clamped to **±Clip Input** around Center (before sending to Arduino).
- **A2 Slew-rate limiter (PC-side):** per-tick target step is capped (prevents aggressive starts / square jumps).
- **Soft-start on mode change:** entering any auto mode starts from current feedback (prevents “kick” on start).

Defaults (auto modes only):
- Freq = **0.5 Hz**
- Amp M1/M2 = **150**
- Motion Range M1/M2 = **50%**

Unchanged:
- Manual / UDP / Monitor logic unchanged.
- No changes to Arduino firmware or protocol.
- UI baseline 9E.B3e preserved (no layout/UX changes).

Date: 2026-01-07




## v1.4.27 — Motion: better default parameters (no functional logic changes)

Changed (defaults only):
- Updated Sine panel defaults (re-used by Motion) to match the stable “works great” baseline:
  - Freq default: **0.60 Hz**
  - Amp M1/M2 default: **350**
  - Center M1/M2 default: **512**
  - Range M1/M2 default remains **50%**

Notes / Compatibility:
- UI baseline (9E.B3e) preserved — no layout/UX polish changes.
- No changes to protocol/firmware/safety.
- Manual / Sine / Triangle / Square / UDP unchanged (only their initial default values updated).

Date: 2026-01-07


## v1.4.26 — Motion: phase-continuous sine + AM envelope (no kicks, no lag)

Changed (Motion mode only):
- Motion waveform is now **pure Sine with continuous phase** (no per-segment resets).
- Segment logic now modulates **only the envelope** (AM-style): small → bigger → max → smaller, with smooth ramps.
- Removed Motion EMA lag (“mułowatość”); kept only a gentle **slew limiter** to prevent rare frame kicks.
- Range M1/M2 default remains **50%**.

Notes / Compatibility:
- UI baseline (9E.B3e) preserved — no layout/UX polish changes.
- No changes to protocol/firmware/safety.
- Manual / Sine / Triangle / Square / UDP unchanged.

Date: 2026-01-07


## v1.4.25 — Motion: faster response (Sine-like speed) + keeps anti-kick

Changed (Motion mode only):
- Tuned Motion output filter to restore responsiveness closer to **Sine**:
  - EMA time constant reduced (snappier tracking).
  - Slew-rate limiter cap increased (less sluggish, still prevents sudden kicks).

Notes / Compatibility:
- UI baseline (9E.B3e) preserved — no layout/UX polish changes.
- No changes to protocol/firmware/safety.
- Manual / Sine / Triangle / Square / UDP unchanged.

Date: 2026-01-07


## v1.4.24 — Motion calmer: smoother segments + output anti-jerk (NO UI changes)

Changed (Motion mode only):
- Calmer segment envelope sequence: smaller step-to-step changes for “small → bigger → max → smaller” flow.
- Longer envelope ramps between segments (gentler rise/fall).
- NEW: Motion output calming filter:
  - EMA low-pass on targets
  - Slew-rate limiter per tick (caps sudden target jumps)

Defaults:
- Range M1 / Range M2 sliders now start at **50%** (previously 100%).

Notes / Compatibility:
- UI baseline (9E.B3e) preserved — no layout/UX polish changes.
- No changes to protocol/firmware/safety.
- Manual / Sine / Triangle / Square / UDP unchanged.

Date: 2026-01-07


## v1.4.22 — Motion: local simulator (segment generator)

- NEW: Motion (soon) działa jako lokalny generator ruchu (bez UDP).
  - sterowanie bez zmian UI: Freq = tempo, Amp M1/M2 = intensywność, Center M1/M2 = baza.
  - generator segmentowy: małe → większe → prawie do granic → znowu mniejsze (płynnie).
- Brak zmian w: UI/UX (baseline), protokole, safety, firmware.

## v1.4.17 — Hotfix: app start (IndentationError)
- FIX: resolved a Python `IndentationError` in UDP helper methods that prevented the app from starting.
- No UI/layout changes. No protocol/firmware changes.

Date: 2026-01-06


## v1.4.16 — UDP listener activation fix
- FIX: UDP pass-through listener now reliably starts when entering UDP mode and also when pressing ENA.
- FIX: UDP motion-state is reset on listener start so the motion loop can clearly show `udp_waiting` until first packet.
- No UI/layout changes. No protocol/firmware changes.


Date: 2026-01-06

## Added
- UDP pass-through mode (configurable via `udp_config.json`):
  - Listens on UDP port **4123** by default.
  - Payload format: **two_ints_csv** (e.g. `512,700`) mapped to Motor 1/2 targets.
  - Timeout: **250 ms**; on timeout uses **hold_last** (keeps last received targets).

## Notes / Compatibility
- No UI changes (baseline UI 9E.B3e preserved).
- No firmware / protocol / safety changes.
- Manual / Sine / Triangle / Square unchanged.

---

# ForgeMotionSMC3tool v1.4.14 — Hard Triangle Wave (Generator)

## Summary
Functional update to generator modes. **Triangle** now uses a hard, linear triangle waveform so it is clearly distinguishable from Sine on plots and in motion.

## Changed
- **Triangle mode waveform:** replaced the previous smooth approximation (`asin(sin())`) with a true **linear triangle wave** in the range `[-1..1]`.
  - Effect: targets ramp linearly up/down over time; corners are sharper and easier to recognize.

## Notes
- No UI layout changes (UI 9E.B3e baseline preserved).
- No changes to Arduino firmware/protocol.
- Sine and Square generator behaviours unchanged.

## Compatibility
- Works with the existing ForgeMotion/SMC3 Arduino firmware.


## v1.4.23 — Motion: per-motor range sliders + smoother segment transitions

- **Motion**: added two per-motor sliders in the existing Sine panel:
  - `Range M1` (0–100%)
  - `Range M2` (0–100%)
  These scale the *effective* Motion amplitude per motor; `Amp M1/M2` remain the max range.
- **Motion**: reduced jerks by smoothing (easing) the envelope steps between motion segments.
- INI: saves/loads `motion_range1` and `motion_range2` in the `*.Modes` section.

Notes:
- No changes to existing UI layout outside the Motion sliders (baseline preserved).
- No firmware/protocol/safety changes.

## v1.4.44 — UI/i18n + Manual v1.1 + Quick Start + Tuning Checklist
- i18n: EN Help menu labels fixed (Help/Manual/Quick Start/Checklist/Disclaimer)
- PL: Profiles destination 'All boards' translated to 'Wszystkie płytki' and refreshed after language change
- Help menu: added Quick Start (1 screen) and Tuning Checklist popups
- Manual updated to v1.1 (expanded tuning explanations + firmware startup reset procedure)
- Popup messaging aligned to language (PL/EN)

## v1.4.45 — i18n: missing keys (EN/PL)
- i18n: added missing translation keys used by UI (prevents showing raw keys in widgets).

## v1.4.47 — UI: wrap mode descriptions + version label
- UI: mode description labels wrap properly in the Mode panel (no overflow).
- UI: window title/version label updated to match SemVer.

## v1.5.0 — Soft-Authorization popup (creator website visit)
- New (UI-only): blocking authorization popup on first run and then every 14 days.
  - Single button opens the creator website.
  - Local-only timestamp state (no accounts/keys/server).
  - Language: PL when system language is PL; otherwise EN.
## v1.5.1 — i18n: robust Windows language detection (PL/EN) [2026-01-13]
- Fix: detect Windows UI language reliably; PL systems now default to Polish UI.


## v1.5.2 — i18n: remove hardcoded UI labels (Mode/Motor headers/Apply dialogs)
- i18n: replaced remaining hardcoded UI labels with translation keys:
  - Mode label uses i18n binding (lbl_mode).
  - Tuning table headers use i18n (hdr_motor1/hdr_motor2).
  - Apply warning dialogs use i18n title (apply_title).
- i18n: fixed EN apply dialog title (was accidentally Polish).
