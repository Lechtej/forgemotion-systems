# ForgeMotionSMC3tool — Manual (EN)

## 1. Purpose
ForgeMotionSMC3tool is a desktop tuning and test tool for **multiple** SMC3-compatible Arduino motor controllers (multi-board / 2 motors per board).

## 2. Safety (read first)
- Keep the rig lifted / unloaded for first tests.
- Use **Enable (ENA)** only when you are ready for motion.
- Prefer **Apply-Safe** (default). Full Apply is available only with an explicit risky-confirm flow.
- If anything behaves unexpectedly: **Disable (ENA off)**, stop motion mode, disconnect.

## 3. Connection
1. Select the COM port number (e.g., `7` → `COM7`).
2. Click **Connect**.
3. Verify telemetry/plots update (Feedback series).

## 4. Read-back baseline
Run **Restore from Arduino** (per motor) to load current Arduino values into UI and to set a safe baseline for Apply gating.

## 5. Tuning workflow (recommended)
1. Start in **Monitor**.
2. Adjust PID / PWM / limits in UI.
3. Click **Apply to Arduino** (SAFE changes only).
4. Validate on plots (Target vs Feedback) and behavior.
5. Save:
   - **Save EEPROM (sav)** to persist in Arduino, or
   - **Save INI** to store profiles on PC (multi-board).

## 6. Modes (overview)
- **Monitor**: telemetry only (this app does not send targets).
- **Manual**: sends target A/B from sliders.
- **Sine / Triangle / Square / Motion**: target generators for testing (use with caution).
- **UDP pass-through**: receives targets via UDP (see `udp_config.json`).

## 7. Plots (how to read)
- **Target**: commanded position
- **Feedback**: measured position
- **PWM (scaled)**: drive output (scaled for plotting)

Limit lines (Clip / Cutoff) visualize configured constraints.

## 8. Known limits
- This tool does not replace hardware safeties (fuses, E-stop, mechanical stops).
- Generator modes can produce aggressive motion if configured improperly.

