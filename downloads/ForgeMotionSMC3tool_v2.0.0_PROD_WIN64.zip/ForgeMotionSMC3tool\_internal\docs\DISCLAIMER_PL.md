# Disclaimer (PL)

Koncepcja **workflow testów** oraz **wizualizacji wykresów** w tej aplikacji bazuje na podejściu znanym z ekosystemu SMC3 oraz narzędzia SMC3Utils.

**ForgeMotionSMC3tool** jest jednak całkowicie nowym rozwiązaniem, napisanym od zera, stworzonym w celu ułatwienia pracy na zestawach symulatorów składających się z **więcej niż jednej** płytki sterującej Arduino (multi-board / multi-motor).

- SMC3 / SMC3Utils są przywołane jako odniesienie koncepcyjne i kompatybilnościowe.
- ForgeMotionSMC3tool nie jest oficjalnym projektem SMC3 i nie jest powiązany z autorami SMC3/SMC3Utils.
- Używasz na własną odpowiedzialność. Zawsze weryfikuj bezpieczeństwo na sprzęcie (E-stop, bezpieczniki, ograniczniki mechaniczne).

