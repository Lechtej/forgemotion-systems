﻿ForgeMotion SMC3tool v2.0.0 (PROD WIN64)
=======================================

Start:
  ForgeMotionSMC3tool.exe

Wymagania:
  - Windows 10/11 x64
  - Python NIE jest wymagany

Uwagi:
  - Folder _internal musi pozostać obok EXE
  - Jeśli SmartScreen blokuje: More info -> Run anyway
