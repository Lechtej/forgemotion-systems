# ForgeMotionSMC3tool — Apply Safe (v1.3.x) — TECH NOTE (Freeze)

## Cel
Zapewnić bezpieczne, przewidywalne i audytowalne wysyłanie parametrów do Arduino:
- brak „ślepego” Apply,
- Apply zależny od Read-back (baseline),
- jawny podział SAFE vs RISKY,
- brak auto-apply.

## Słownik
- **baseline**: zestaw parametrów odczytany z Arduino po Read-back OK (16/16). Tylko baseline jest „prawdą” o stanie płytki.
- **INI pending**: wartości wczytane z pliku INI, które mogą wprowadzać różnice względem baseline; wymagają świadomego Apply.
- **SAFE params**: zmiany konserwatywne; Apply bez dodatkowych kroków.
- **RISKY params**: zmiany mogące wpływać na zachowanie napędu w sposób trudny do przewidzenia; wymagają SHIFT+Apply.

## Klasyfikacja parametrów (Freeze)
SAFE:
- Kp, Ki, Kd
- PWM min, PWM max
- Max Limits, Clip Input, Deadzone

RISKY:
- fpwm (kHz)
- fpid_div (divider)
- pwmrev
- Ks
- każde nieznane pole (default: RISKY)

## Stany Apply (logiczne)
- DISCONNECTED: brak połączenia
- RB_REQUIRED: brak baseline (wymagany Read-back)
- RB_ACTIVE: Read-back w toku
- NO_CHANGES: UI == baseline
- READY_SAFE: wykryte zmiany tylko w SAFE
- READY_RISKY: wykryto co najmniej jedną zmianę RISKY
- INVALID: naruszone reguły zakresów / zależności

## Reguły zależności (blokada = INVALID)
Dla każdego silnika osobno:
- pwmmin <= pwmmax
- pwmrev <= pwmmax
- lim <= pwmmax
- clip <= lim
- dead <= clip

## Zasady Apply
- Apply aktywne tylko w READY_SAFE / READY_RISKY
- READY_SAFE → wykonuje SAFE_APPLY (wysyłane tylko SAFE, RISKY zachowane z baseline)
- READY_RISKY → zwykły klik: blok + ostrzeżenie; SHIFT+klik → pełny Apply (risky)
- po udanym Apply baseline aktualizowany „optymistycznie”
- brak auto-apply

## INI (ALL boards)
- Load INI nie nadpisuje baseline; ustawia INI pending
- Save INI zablokowane, jeśli brak baseline na którejkolwiek płytce (żeby nie zapisywać „zgadywanki”)
- po Apply (safe/full) INI pending jest czyszczone
- jeśli Load INI nie powoduje różnic vs baseline → INI pending czyszczone

## UI-minimum (bez redesignu)
Badge obok Apply:
- `BL:yes/no INI:yes/no <STATE>`

## Logi audytowe
- `logs/apply_safe_Board_X.log` — decyzje stanu, powody, safe/risky listy, blokady SHIFT, INI load/save, czyszczenie INI pending
